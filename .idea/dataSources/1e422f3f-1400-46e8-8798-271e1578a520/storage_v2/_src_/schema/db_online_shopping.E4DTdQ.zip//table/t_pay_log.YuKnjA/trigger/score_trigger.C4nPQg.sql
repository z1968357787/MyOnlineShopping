create definer = js_2022@`%` trigger score_trigger
    after update
    on t_pay_log
    for each row
begin
    update t_product_description set score=(select avg(score) from t_pay_log where t_pay_log.product_id=new.product_id) where product_id=NEW.product_id;
end;

