create definer = js_2022@`%` view v_evaluation as
select `db_online_shopping`.`t_pay_log`.`user_id`              AS `user_id`,
       `db_online_shopping`.`t_user`.`user_name`               AS `user_name`,
       `db_online_shopping`.`t_pay_log`.`product_id`           AS `product_id`,
       `db_online_shopping`.`t_pay_log`.`product_name`         AS `product_name`,
       `db_online_shopping`.`t_product_description`.`supplier` AS `supplier`,
       `db_online_shopping`.`t_pay_log`.`pay_date`             AS `pay_date`,
       `db_online_shopping`.`t_pay_log`.`score`                AS `score`,
       `db_online_shopping`.`t_pay_log`.`evaluation`           AS `evaluation`
from `db_online_shopping`.`t_pay_log`
         join `db_online_shopping`.`t_product_description`
         join `db_online_shopping`.`t_user`
where ((`db_online_shopping`.`t_pay_log`.`product_id` = `db_online_shopping`.`t_product_description`.`product_id`) and
       (`db_online_shopping`.`t_pay_log`.`user_id` = `db_online_shopping`.`t_user`.`id`) and
       (`db_online_shopping`.`t_pay_log`.`score` is not null));

